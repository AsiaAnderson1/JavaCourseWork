/* IT--2650 Java Programming, Spring 2020
* Instructor: David Goff
* Student Name: Asia Anderson
* Homework Assignment: Chap 5, Problem 5
* Purpose of Assignment: Prompt user to insert month,day,year and compare it to current date.
*/
package com.mycompany.ama_first_last_present;
import java.util.Scanner;
import java.time.LocalDate;

/**
 *
 * @author Asia
 */
public class AMA_First_Last_Present {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        LocalDate today = LocalDate.now();
        int month;
        int year;
        int todayMonth;
        int todayYear;
        int day;
        
        todayMonth = today.getMonthValue();
        todayYear = today.getYear();

        Scanner userInput = new Scanner(System.in);
        
        System.out.println("Give me the month,date, and year.");
        month = userInput.nextInt();
        day = userInput.nextInt();
        year = userInput.nextInt();
        
        if( todayYear != year )
        {
            System.out.println("That date is not this year.");
        }
        if ( todayYear == year && todayMonth > month)
        {
            System.out.println("That date was early this year.");
        }
        if ( todayYear == year && todayMonth < month)
        {
            System.out.println("That date is later this year.");
        }
        if ( todayYear == year && todayMonth == month)
        {
            System.out.println("This date is this month.");
        }
    }
    
}
